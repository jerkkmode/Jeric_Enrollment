<?php
/*
$dbhost ="localhost";
$dbuser ="root";
$dbpass ="";
$db 	="enrollment";

$conn = new mysqli ($dbhost, $dbuser, $dbpass,$db) ;

if($conn->connect_error) {
	echo "connection failed";
}
else {
	echo "connection successful";
}
*/
	require('config/config.php');
	require('config/db.php');
	

	if(isset($_POST['submit']))
	{
		
		$fname = mysqli_real_escape_string($conn, $_POST['fname']);
		$mname = mysqli_real_escape_string($conn, $_POST['mname']);
		$lname = mysqli_real_escape_string($conn, $_POST['lname']);
		$age = mysqli_real_escape_string($conn, $_POST['age']);
		$bday = mysqli_real_escape_string($conn, $_POST['bday']);
		$sex= mysqli_real_escape_string($conn, $_POST['sex']);
		
	$query = "INSERT INTO enrollment(fname, mname, lname, age, bday, sex) VALUES ('$fname', '$mname', '$lname', 'age', 'bday', 'sex')";

	if(mysqli_query($conn, $query))
	{
		header('Location:'.ROOT_URL.'');
	}
	else{ echo 'ERROR:' .msqli_error($conn);}

}
?>