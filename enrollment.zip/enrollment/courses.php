<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="icon" href="./img/excel.ico" type="image" sizes="16x16">
	<title>Excel Technical Skills and Career Center</title>
	<style type="text/css">
	body{
		padding-top: 130px;
		background-color: #f2f2f2;
	}
		a.navbar-brand{
			color: black;
			padding:0px 30px 0px;
		}
		#idLogo{
		height: 50px;
		width: 50px;
		margin-left: 150px;
	}
	#idTitle{
		color: black;
		font-family: Cambria;
		font-size: 150%;
		margin: 0px 0px;
		padding: 0px 0px;
	}
	#idBack{
		color:blue;
		margin-bottom: 0px;
	}	
	img {
		margin: 10px 20px;	
	}
	h3{
		text-align: center;
	}
	.app-footer {
		background-color: #333333;
		color: white;
		padding: 50px;
		font-size: 15px;
	}
	</style>
</head>
<body>
	<header class= "bg-light text-white p-15 mb-5 navbar navbar-expand-lg fixed-top">
		<div class="container">
		<img id="idLogo" src="./img/logo.jpg"><p id="idTitle">Excel Technical Skills and Training Center </p>
		</div>
		<div class="nav navbar">
			<ul style="list-style: none; display: inline-flex;  padding-left: 250px; ">
				<a class="navbar-brand" href="index.php">Home</a>
				<a class="navbar-brand" href="about.php">About Us</a>
				<a class="navbar-brand" href="courses.php">Courses</a>
			</ul>
		</div>
	</header>
	<div class="container">
		<a href="index.php"><p id="idBack">Back to Home</p></a>
	</div>
	<div class="container">
		<h3>Our Offered Courses</h3>
		<div class="row">
			<div class="container">
			<img src="./img/wbdes.png">
			<img src="./img/wbdv.jpg">
			<img src="./img/ems.jpg">
			<img src="./img/tm.jpg">		
			</div>
		</div>		
	</div>
	<footer class="app-footer">
	    <div>
	        <span>Created by &copy;<a href="https://getbootstrap.com">jerkkmode</a></span>
	      </div>
  	</footer>
</body>
</html>