<?php
		#Create Connection
		$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
		//Check Connection
	if(mysqli_connect_error())
{
		//connection failed
		echo 'failed to connect to'.mysqli_connect_errno();
}
?>