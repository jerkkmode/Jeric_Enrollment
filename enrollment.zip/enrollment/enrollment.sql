-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2019 at 10:30 AM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enrollment`
--

-- --------------------------------------------------------

--
-- Table structure for table `studentaccounts`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `std_info` (
  `id` int(90) NOT NULL,
  `fname` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `mname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `age` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `bday` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sex` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `std_info` (`id`, `fname`, `mname`, `lname`, `age`, `bday`, 'sex') VALUES
(5, 'Mark', 'Dela Cruz', 'Santos', '18', '2001-01-02', 'Male');


-- --------------------------------------------------------

--
-- Table structure for table `webdesign`
--

CREATE TABLE `address` (
  'id' int(255) NOT NULL,
  'strtname' varchar(255) NOT NULL,
  `brgy` varchar(90) NOT NULL,
  `city` varchar(90) NOT NULL,
  `telephone` int(90) NOT NULL,
  `contact` int(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `webdesign`
--

INSERT INTO `address` (`id`, `strtname`, `brgy`, `city`, `telephone`, `contact`) VALUES
(5, 'Blk 1 Lot 4','Tumana', 'Marikina', '2587895', '917758841');

-- --------------------------------------------------------

--
-- Table structure for table `webdev`
--


--
-- Dumping data for table `webdev`
--


--
-- Indexes for dumped tables
--

--
-- Indexes for table `studentaccounts`
--


--
-- Indexes for table `users`
--
ALTER TABLE `std_info`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `webdesign`
--

-- Indexes for table `webdev`
--

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `studentaccounts`
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `std_info`
  MODIFY `id` int(90) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

ALTER TABLE `address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
  COMMIT;


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
