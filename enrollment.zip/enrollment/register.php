<?php
	require('config/config.php');
	require('config/db.php');
	

	if(isset($_POST['submit']))
	{
		
		$fname = mysqli_real_escape_string($conn, $_POST['fname']);
		$mname = mysqli_real_escape_string($conn, $_POST['mname']);
		$lname = mysqli_real_escape_string($conn, $_POST['lname']);
		$age = mysqli_real_escape_string($conn, $_POST['age']);
		$bday = mysqli_real_escape_string($conn, $_POST['bday']);
		$sex= mysqli_real_escape_string($conn, $_POST['sex']);
		
	$query = "INSERT INTO std_info(fname, mname, lname, age, bday, sex) VALUES ('$fname', '$mname', '$lname', '$age', '$bday', '$sex')";

	if(mysqli_query($conn, $query))
	{
		header('Location:'.ROOT_URL.'');
	}
	else{ echo 'ERROR:' .msqli_error($conn);}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="icon" href="./img/excel.ico" type="image" sizes="16x16">
	<title>Excel Technical Skills and Career Center</title>
	<style type="text/css">
	body{
		padding-top: 130px;
		background-color: #f2f2f2;
	}
	#header{
		margin-right: 640px;
	}
	#idLogo{
		height: 50px;
		width: 70px;
		margin: auto;
	}
	#idTitle{
		padding: 0px 0px;
		color: black;
		font-family: Cambria;
		font-size: 150%;
	}
	#idBack{
		color:blue;
		margin-bottom: 0px;
	}	
	.form-group {
		display: inline-block;
	}
	.app-footer {
		background-color: #333333;
		color: white;
		padding: 50px;
		font-size: 15px;
	}
	</style>
</head>
<body>
	<header class= "navbar navbar-expand-md bg-light fixed-top">
		<div id="header" class="container">
			<img id="idLogo" src="./img/logo.jpg"><p id="idTitle">Excel Technical Skills and Training Center </p>
		</div>
	</header>
	<div class="container">
		<a href="index.php"><p id="idBack">Back to Home</p></a>
	</div>
	<div class="container">
		<div class="jumbotron">
			<h4 style="font-family: 'Cambria';">Please fill out the application form for new students</h4>
		</div>
		<div class="container">
			<form method="POST" action="<?php $_SERVER['PHP_SELF']; ?>">
			<div class="form-group">
				<label>First Name</label>
				<input type="text" name= "fname" class="form-control" placeholder=" ex. Mark" required="">
			</div>
			<div class="form-group">
				<label>Middle Name</label>
				<input type="text" name= "mname" class="form-control" placeholder=" ex. Johnson" required="" >
			</div>
			<div class="form-group">
				<label>Last Name</label>
				<input type="text" name= "lname" class="form-control" placeholder=" ex. Dela Cruz" required="" >
			</div>
			<div class="form-group">
				<label>Age</label>
				<input type="num" name= "age" class="form-control" placeholder=" ex. 64" required="" >
			</div>
			<div class="form-group">
				<label>Birthdate</label>
				<input type="date" name= "bday" max="2001-12-31" class="form-control" required="" >
			</div>
			<div class="form-group">
				<label>Sex</label>
				<select name="sex" required="">
	   				<option selected="" >Female</option>
	    			<option>Male</option>
  				</select>
			</div>
			<div class="form-group">
				<label>Block/Lot/Street</label>
				<input type="text" name= "strtname" class="form-control" placeholder=" ex. 1 blk 1 lot"  >
			</div>
			<div class="form-group">
				<label>Brgy/Village</label>
				<input type="text" name= "brgy" class="form-control" placeholder=" ex. San Roque" >
			</div>
			<div class="form-group">
				<label>City/Municipality</label>
				<input type="text" name= "city" class="form-control" placeholder=" ex. Marinduque" >
			</div>
			<div class="form-group">
				<label>Telephone No.</label>
				<input type="tel" name= "telephone" class="form-control" placeholder=" ex.000-00-00" pattern="[0-9]{3}-[0-9]{2}-[0-9]{2}" >
			</div>
			<div class="form-group">
				<label>Contact No.</label>
				<input type="tel" name= "contact" class="form-control" placeholder=" ex. 09123456789" pattern="[0-9]{11}" >
			</div>
			<div class="form-group">
				<label>Email</label>
				<input type="email" name= "email" size="7" class="form-control" placeholder=" ex. juandelacruz@yahoo.com">
			</div>
			<div class="form-group">
				<label>Did you take a TESDA Accredited training before?</label>
				<input type="radio" name="chooseone" value="yes" checked>Yes
				<input type="radio" name="chooseone" value="no">No
			</div>
			<div class="form">
				<label>If Yes, Please indicate the duration, training center, and the assesor:</label>
				<textarea rows="6" cols="60"></textarea>
			</div>
			<div class="form-group">
				<label>What course are you taking?</label>
				<select name="course" >
	   				<option value="Creative Web Design">Creative Web Design</option>
	    			<option value="Web Development">Web Development</option>
	    			<option value="Trainer's Methodology">Trainer's Methodology</option>
	    			<option value="Event's Management">Event's Management</option>
  				</select>
			</div>
			<br>			
			<button type="submit" name="submit" class="btn btn-success" href="<?php echo ROOT_URL;?>index.php" style="color: white;">Submit</button>
			</form>
		</div>
	</div><br>
	<footer class="app-footer">
	    <div>
	        <span>Created by &copy;<a href="https://getbootstrap.com">jerkkmode</a></span>
	      </div>
  	</footer>
</body>
</html>