<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="icon" href="./img/excel.ico" type="image" sizes="16x16">
	<title>Excel Technical Skills and Career Center</title>
	<style type="text/css">
	body{
		padding-top: 130px;
		background-color: #f2f2f2;
	}
	a.navbar-brand{
		color: black;
		padding:0px 30px 0px;
		}
	#idLogo{
		height: 50px;
		width: 50px;
		margin-left: 150px;
	}
	#idTitle{
		color: black;
		font-family: Cambria;
		font-size: 150%;
		margin: 0px 0px;
		padding: 0px 0px;
	}
	#idBack{
		color:blue;
		margin-bottom: 0px;
	}	
	.app-footer {
		background-color: #333333;
		color: white;
		padding: 50px;
		font-size: 15px;
	}
	</style>
</head>
<body>
	<header class= "bg-light text-white p-15 mb-5 navbar navbar-expand-lg fixed-top">
		<div class="container">
		<img id="idLogo" src="./img/logo.jpg"><p id="idTitle">Excel Technical Skills and Training Center </p>
		</div>
		<div class="nav navbar">
			<ul style="list-style: none; display: inline-flex;  padding-left: 250px; ">
				<a class="navbar-brand" href="index.php">Home</a>
				<a class="navbar-brand" href="about.php">About Us</a>
				<a class="navbar-brand" href="courses.php">Courses</a>
			</ul>
		</div>
	</header>
	<div class="container">
		<a href="index.php"><p id="idBack">Back to Home</p></a>
	</div>
	<div class="container">
		<div class="jumbotron text-center">
			<h2>About us</h2>
		</div>		
	</div>
	<div class="container">
		<div class="row">
			<div class="container">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras lobortis enim at ipsum feugiat viverra. Fusce vel eros sed nisi commodo tristique. Fusce in felis hendrerit, consectetur ex id, laoreet ligula. Ut malesuada quam massa, eget tempus sem rhoncus a. Etiam lectus eros, condimentum nec varius vitae, dictum ut arcu. Ut lectus eros, commodo ac odio vitae, vehicula elementum ante. Nulla facilisi. Quisque pulvinar ac risus quis gravida. Proin volutpat cursus pharetra. Vivamus volutpat tincidunt ligula, eget dignissim tellus sollicitudin eu. Integer nibh ipsum, bibendum at iaculis at, dapibus euismod mauris. Ut vel facilisis odio. Pellentesque sed aliquam mauris.</p>
			</div>
		
			<div class="col-md-8">
				<p>Fusce lacinia porttitor est, a tempor massa ultrices sit amet. Sed suscipit ipsum nec tempus porttitor. Duis viverra, diam et pellentesque porttitor, lorem eros bibendum lacus, sit amet volutpat sem odio eu felis. Sed ut ligula vel enim condimentum dignissim in vitae ante. Cras convallis nibh ut facilisis maximus. Nunc auctor molestie sapien. Mauris bibendum leo ut justo malesuada, quis venenatis orci pharetra. Morbi dignissim consectetur massa eu efficitur. Nulla eget congue erat.</p>
			</div>
			<div class="col-md-4">
				<p>Ut vestibulum tellus ac sollicitudin gravida. Nulla id suscipit nunc.  Nam facilisis congue dui in ornare. Duis non nulla a. </p>
			</div>
			<div class="col-md-8">
				<p>Maecenas placerat, dolor vel aliquam imperdiet, lorem turpis lobortis velit, non pretium orci dolor sed ligula. Aliquam suscipit enim sit amet lacus malesuada lobortis. Etiam id ex sapien. Nulla facilisi. Fusce ut lacus pharetra, euismod sem sit amet, iaculis ante. Suspendisse sit amet dolor sit amet augue ultricies posuere. Mauris ultrices turpis vel dapibus bibendum. Morbi suscipit ligula sed erat ultrices varius. Fusce non arcu ornare ipsum malesuada facilisis.</p>
			</div>
			<div class="col-md-4">
				<img src="./img/logo.jpg" style="width: 100px; height: 100px;">
			</div>		
			<div class="col-md-8">
				<p>Morbi auctor, metus ac semper ultricies, nunc nisi dignissim magna, in sodales nibh libero nec odio. Cras vulputate enim quam, sed consectetur ligula dignissim eu. Morbi egestas libero ex, ac tincidunt libero condimentum vitae. Praesent et augue ac erat porttitor faucibus. Vestibulum convallis vehicula malesuada. In hac habitasse platea dictumst. Vestibulum quis commodo nisl, et scelerisque leo. Donec molestie ultricies mi, et tempus diam dapibus ullamcorper. Proin fermentum fringilla quam a tempor. Aenean sit amet leo eu risus eleifend porta. Sed in venenatis nisl. Phasellus bibendum, nunc in molestie luctus, lorem risus auctor ante, eu faucibus nunc odio eget enim. Duis vel semper quam, ac auctor purus. Curabitur non tellus ut augue porta malesuada et eu velit.</p>
			</div>
			<div class="col-md-4">
				<p>Ut vestibulum tellus ac sollicitudin gravida. Nulla id suscipit nunc. Nam facilisis congue dui in ornare. Duis non nulla a.</p>
			</div>		
			<div class="col-md-8">
				<p>Proin felis lacus, ullamcorper a ligula at, placerat dapibus massa. In aliquam, turpis sed tempor rhoncus, elit metus tempor sem, non scelerisque enim metus venenatis turpis. Praesent elit turpis, fringilla sed urna eu, sagittis lobortis ipsum. Nulla facilisi. Quisque ipsum leo, ornare ac justo in, elementum faucibus ipsum. Proin placerat efficitur tempus. Maecenas id urna ultrices, viverra elit vel, imperdiet risus. Mauris dictum velit in sagittis efficitur. Maecenas cursus tortor quis erat euismod pharetra. Interdum et malesuada fames ac ante ipsum primis in faucibus. In felis arcu, eleifend non lacus sed, elementum iaculis erat. Curabitur non fringilla ipsum. Aliquam cursus mi diam. </p>
			</div>
			<div class="col-md-4">
				<p>Ut vestibulum tellus ac sollicitudin gravida. Nulla id suscipit nunc. Nam facilisis congue dui in ornare. Duis non nulla a.</p>
			</div>			
		</div>
		
	</div>
<footer class="app-footer">
	    <div>
	        <span>Created by &copy;<a href="https://getbootstrap.com">jerkkmode</a></span>
	      </div>
  	</footer>
</body>
</html>